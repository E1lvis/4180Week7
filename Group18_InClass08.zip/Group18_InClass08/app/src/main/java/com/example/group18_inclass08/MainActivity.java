//In class 08
//Group18_InClass08
//Elvis Velasquez, Eduardo Gomez

package com.example.group18_inclass08;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;



//main fragment is contaListFragment in case of confusion
public class MainActivity extends AppCompatActivity implements ContactListFragment.Listener, NewContactFragment.NCListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView, new ContactListFragment(), "mainFragment")
                .commit();
    }

    @Override
    public void addButtonClicked() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new NewContactFragment(), "newContactFragment")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void cancel() {
        getSupportFragmentManager().popBackStack();
    }

    @Override
    public void submit() {
        getSupportFragmentManager().popBackStack();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new ContactListFragment(), "ContactFragment")
                .addToBackStack(null)
                .commit();
    }
}