package com.example.group18_inclass08;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link NewContactFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NewContactFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public NewContactFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment NewContactFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static NewContactFragment newInstance(String param1, String param2) {
        NewContactFragment fragment = new NewContactFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_new_contact, container, false);

        Button submit = view.findViewById(R.id.buttonSubmit);
        Button cancel = view.findViewById(R.id.buttonCancel);

        TextView name = view.findViewById(R.id.editTextName);
        TextView email = view.findViewById(R.id.editTextEmail);
        TextView number = view.findViewById(R.id.editTextNumber);
        TextView type = view.findViewById(R.id.editTextType);
        //
        //NOTE NOTE! type has to be either CELL OFFICE or HOME exactly caps sensistive, maybe we should a dropdown instead?
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                li.cancel();
            }
        });

        //on clcik check if all areas are filled then post the new contact using the create contact funciton
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(name.getText().toString().length() == 0 || type.getText().toString().length() == 0 || email.getText().toString().length() == 0 || number.getText().toString().length() == 0){
                    Toast.makeText(getActivity(), "Please enter all info.", Toast.LENGTH_SHORT).show();
                } else{
                    createContact(name.getText().toString(), email.getText().toString(), type.getText().toString(), number.getText().toString());
                    li.submit();

                }

            }
        });




        // Inflate the layout for this fragment
        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof NCListener){
            li = (NCListener) context;
        }
    }

    NCListener li;
    interface NCListener{
        void cancel();
        void submit();
    }
    private final OkHttpClient client = new OkHttpClient();
    void createContact(String name, String email, String type, String phone){
        FormBody formBody = new FormBody.Builder()
                .add("name", name)
                .add("email", email)
                .add("type", type)
                .add("phone", phone)
                .build();

        Request request = new Request.Builder()
                .url("https://www.theappsdr.com/contact/json/create")
                .post(formBody)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                ResponseBody re = response.body();
                String body = re.string();
                Log.d("", "onResponse: yea" + body);
            }
        });
    }
}