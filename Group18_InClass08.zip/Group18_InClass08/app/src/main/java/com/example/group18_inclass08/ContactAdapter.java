package com.example.group18_inclass08;

import android.content.Context;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;


public class ContactAdapter extends ArrayAdapter<contact> {
    public ContactAdapter(@NonNull Context context, int resource, @NonNull List<contact> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.contact_adapter_layout, parent, false);

        }

        TextView name = convertView.findViewById(R.id.textViewName);
        TextView email = convertView.findViewById(R.id.textViewEmail);
        TextView number = convertView.findViewById(R.id.textViewPhoneNumber);
        TextView type = convertView.findViewById(R.id.textViewPhoneType);


        contact temp = getItem(position);

        name.setText(temp.getName());
        email.setText(temp.getEmail());
        number.setText(temp.getNumber());
        type.setText(temp.getPhoneType());



        return convertView;
    }
}