package edu.uncc.weather;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.HttpUrl;

import java.io.IOException;

import java.text.DecimalFormat;

import edu.uncc.weather.databinding.FragmentCurrentWeatherBinding;

public class CurrentWeatherFragment extends Fragment {
    private static final String ARG_PARAM_CITY = "ARG_PARAM_CITY";
    private DataService.City mCity;
    FragmentCurrentWeatherBinding binding;
    weather mWeather;
    DecimalFormat dFormat = new DecimalFormat("0.00");
    public static String weatherIconCode;
    public CurrentWeatherFragment() {
        // Required empty public constructor
    }

    public static CurrentWeatherFragment newInstance(DataService.City city) {
        CurrentWeatherFragment fragment = new CurrentWeatherFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM_CITY, city);
        fragment.setArguments(args);
        return fragment;
    }
    private final OkHttpClient client = new OkHttpClient();
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mCity = (DataService.City) getArguments().getSerializable(ARG_PARAM_CITY);
        }
        String myAPIKey = "362407e73ae1a158c708d278c4449102";


        HttpUrl url = HttpUrl.parse("https://api.openweathermap.org/data/2.5/weather").newBuilder()
                .addQueryParameter("lat", String.valueOf(mCity.getLat()))
                .addQueryParameter("lon", String.valueOf(mCity.getLon()))
                .addQueryParameter("appid", myAPIKey)
                .build();

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.d("TAG", "onFailure: Failed");
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                ResponseBody re = response.body();
                String s = re.string();
                Log.d("", "onResponse: " + s);

                try {
                    //for array response
                    JSONObject Json = new JSONObject(s);
                    JSONArray weatherList = Json.getJSONArray("weather");
                    JSONObject w = new JSONObject(String.valueOf(weatherList.getJSONObject(0)));
                    JSONObject main = Json.getJSONObject("main");
                    JSONObject wind = Json.getJSONObject("wind");
                    JSONObject cl = Json.getJSONObject("clouds");

                    Log.d("", "onResponse: array " + weatherList);

                    weatherIconCode = w.getString("icon");

                    mWeather = new weather(main.getString("temp"), main.getString("temp_max"), main.getString("temp_min"), w.getString("description"),
                            main.getString("humidity"), wind.getString("speed"), wind.getString("deg"), cl.getString("all") );


                    /**
                     *
                    Log.d("", "onResponse: " + contactsList);

                    for(int i = 0; i < contactsList.length(); i++){

                        JSONObject temp = contactsList.getJSONObject(i);
                        contact tempContect = new contact(temp.getString("Name"),temp.getString("Email"), temp.getString("Phone"), temp.getString("PhoneType") );
                        contactsArray.add(tempContect);
                        Log.d("TAG", "onResponse: " + i + " " + contactsArray);




                    }
                     */

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        });
        try {

            Thread.sleep(400);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCurrentWeatherBinding.inflate(inflater, container, false);
        Button forecast = binding.getRoot().findViewById(R.id.buttonCheckForecast);
        forecast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.gotoforcast(mCity);
            }
        });

        TextView temp = binding.getRoot().findViewById(R.id.textViewTemp);
        TextView max = binding.getRoot().findViewById(R.id.textViewTempMax);
        TextView min = binding.getRoot().findViewById(R.id.textViewTempMin);
        TextView desc = binding.getRoot().findViewById(R.id.textViewDesc);
        TextView hum = binding.getRoot().findViewById(R.id.textViewHumidity);
        TextView speed = binding.getRoot().findViewById(R.id.textViewWindSpeed);
        TextView deg = binding.getRoot().findViewById(R.id.textViewWindDegree);
        TextView cloudiness = binding.getRoot().findViewById(R.id.textViewCloudiness);


        //the temps are given in kelvin so we do some quick conversions
        String temperature = String.valueOf(dFormat.format((Double.valueOf(mWeather.getTemp()) - 273.15) * 9/5 + 32));
        String maxTemp = String.valueOf(dFormat.format((Double.valueOf(mWeather.getMax()) - 273.15) * 9/5 + 32));
        String minTemp = String.valueOf(dFormat.format((Double.valueOf(mWeather.getMin()) - 273.15) * 9/5 + 32));
        temp.setText(temperature + " F");
        max.setText(maxTemp + " F");
        min.setText(minTemp + " F");
        desc.setText(mWeather.getDes());
        hum.setText(mWeather.getHumidity() + "%");
        speed.setText(mWeather.getSpeed() + "miles/hr");
        deg.setText(mWeather.getDegree() + " degrees");
        cloudiness.setText(mWeather.getCloud() + "%");

        ImageView im = binding.getRoot().findViewById(R.id.imageViewWeatherIcon);
        Log.d("TAG", "onCreateView: icon coded " + weatherIconCode);


            Picasso.get().load("https://openweathermap.org/img/wn/"+ weatherIconCode + ".png").into(im);

            Picasso.get().setLoggingEnabled(true);
            //Picasso.get().load("https://openweathermap.org/img/wn/02n.png").resize(40,40).centerCrop().into(im);



        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Current Weather");
    }

    currentWeatherFragmentListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (currentWeatherFragmentListener) context;
    }

    interface currentWeatherFragmentListener {
        void gotoforcast(DataService.City city);
    }

}