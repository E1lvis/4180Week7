package edu.uncc.weather;

public class weather {
    String temp;
    String max;
    String min;
    String Des;
    String humidity;
    String speed;
    String degree;
    String cloud;

    public weather(String temp, String max, String min, String des, String humidity, String speed, String degree, String cloud) {
        this.temp = temp;
        this.max = max;
        this.min = min;
        Des = des;
        this.humidity = humidity;
        this.speed = speed;
        this.degree = degree;
        this.cloud = cloud;
    }

    @Override
    public String toString() {
        return "weather{" +
                "temp='" + temp + '\'' +
                ", max='" + max + '\'' +
                ", min='" + min + '\'' +
                ", Des='" + Des + '\'' +
                ", humidity='" + humidity + '\'' +
                ", speed='" + speed + '\'' +
                ", degree='" + degree + '\'' +
                ", cloud='" + cloud + '\'' +
                '}';
    }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getMax() {
        return max;
    }

    public void setMax(String max) {
        this.max = max;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getDes() {
        return Des;
    }

    public void setDes(String des) {
        Des = des;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getCloud() {
        return cloud;
    }

    public void setCloud(String cloud) {
        this.cloud = cloud;
    }
}
